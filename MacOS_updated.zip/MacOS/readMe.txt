Для запуска необходимо перенести папку "macOS" на рабочий стол, затем открыть терминал(terminal.app) и вставить команды которые прописаны ниже

cd ~/Desktop/MacOS
python3 open_links_macos.py